document.addEventListener('DOMContentLoaded', function init() {
    //Shuffling through the card deck//

    var stack = document.getElementById('stack-section');

    var nextbutton = document.getElementById("button-next");

    var backbutton = document.getElementById("button-previous");



    nextbutton.addEventListener('click', function() {
        stack.style.visibility = 'hidden';
    });

    backbutton.addEventListener('click', function(){
        stack.style.visibility = 'visible';
    });
});
